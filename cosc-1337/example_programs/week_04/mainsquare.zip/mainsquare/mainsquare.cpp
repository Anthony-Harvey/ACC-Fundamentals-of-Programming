// Michael Miller

#include <iostream>
#include <cstdlib>
#include "square.h"

using namespace std;


int main()  // driver
{
    // two objects
    Square s1, s2(3);

    cout << "s1 side = " << s1.getSide() << endl;
    cout << "s2 side = " << s2.getSide() << endl;
        
    s1.setSide(9);
    s2.setSide(5);
    Square s3(3);

    {
      cout << "-s3 side = " << s3.getSide() << endl;
      Square s3(9);
      cout << "-s3 side = " << s3.getSide() << endl;
    }
    cout << "s3 side = " << s3.getSide() << endl;
    cout << "s1 side = " << s1.getSide() << endl;
    cout << "s2 side = " << s2.getSide() << endl;

    cout << "s1 area = " << s1.getArea() << endl;
    cout << "s2 area = " << s2.getArea() << endl;
    cout << s2.getArea() + s1.getArea() << endl;
        
    system("pause");
    return EXIT_SUCCESS;
}
