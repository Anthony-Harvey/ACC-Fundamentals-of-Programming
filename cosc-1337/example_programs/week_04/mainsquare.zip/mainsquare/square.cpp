#include "square.h"


// implementation
int Square::getArea() 
{   
    return calc();
}
