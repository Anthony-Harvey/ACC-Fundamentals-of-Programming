#include <iostream>

#ifndef SQUARE_H
#define SQUARE_H 1

class Square {
   private:
      int side;  // attribute
      int calc() { return side * side; }  // private
   public:  
      // constructor
      Square() { side = 1; }  // default
      Square(int s) { side = s; }
      void setSide(int s) { side = s; }  // mutator, setter, inline
      int getSide() { return side; }     // acessor, getter, inline
      int getArea(); // prototype
      ~Square() { std::cout << "bye bye" << std::endl; }
};

#endif
